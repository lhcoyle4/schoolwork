This won't compile as I wasn't able to complete the assignment. 

However, I wanted to show that I did start it, I just was not able
to work on it while I was out and I ran out of time.